/*
   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include <string.h>
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "sm2335.h"

static const char *TAG = "SM2335 demo";

#define LED_CH_BLUE  0
#define LED_CH_GREEN 1
#define LED_CH_RED   2
#define LED_CH_WARM  3
#define LED_CH_CLOD  4
/**
 * CH0 - BLUE
 * CH1 - GREEN
 * CH2 - RED
 * CH3 - WARM
 * CH4 - COLD
 * 
 */

void app_main()
{
    ESP_LOGI(TAG, "[APP] Startup..");
    ESP_LOGI(TAG, "[APP] Free memory: %d bytes", esp_get_free_heap_size());
    ESP_LOGI(TAG, "[APP] IDF version: %s", esp_get_idf_version());

    sm2335_init(I2C_NUM_0, 18, 19, 100000);

    sm2335_set_max_current(RGB_CURR_160MA, WY_CURR_80MA);

    uint16_t light[5]={0};
    uint16_t set_light = 0;
    while (1) {

        ESP_LOGI(TAG, "set light %d", set_light);
        sm2335_set_channel(LED_CH_WARM, set_light);
        vTaskDelay(5);
        set_light+=3;
        if (set_light > 1024) {
            set_light = 0;
        }
    }
}